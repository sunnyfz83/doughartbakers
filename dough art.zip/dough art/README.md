# Dough Art - Premium E-commerce Website

A modern, responsive e-commerce website for Dough Art, featuring a beautiful design inspired by the Figma template. This website showcases handcrafted dough art pieces with an elegant and user-friendly interface.

## 🎨 Features

- **Modern Design**: Clean, professional layout with beautiful gradients and animations
- **Responsive Layout**: Fully responsive design that works on all devices
- **Interactive Elements**: Smooth animations, hover effects, and user interactions
- **Product Showcase**: Featured products section with ratings and pricing
- **Newsletter Subscription**: Email subscription functionality
- **Mobile Navigation**: Hamburger menu for mobile devices
- **Search Functionality**: Real-time product search
- **Shopping Cart**: Interactive cart with item counter
- **Smooth Scrolling**: Enhanced navigation experience

## 🚀 Technologies Used

- **HTML5**: Semantic markup structure
- **CSS3**: Modern styling with Flexbox and Grid
- **JavaScript (ES6+)**: Interactive functionality and animations
- **Font Awesome**: Icons and visual elements
- **Google Fonts**: Inter font family for typography
- **Unsplash Images**: High-quality placeholder images

## 📱 Responsive Design

The website is fully responsive and optimized for:
- Desktop (1200px+)
- Tablet (768px - 1199px)
- Mobile (320px - 767px)

## 🎯 Key Sections

1. **Header**: Navigation bar with logo, menu, search, and cart
2. **Hero Section**: Eye-catching banner with call-to-action buttons
3. **Featured Products**: Product grid with hover effects and ratings
4. **About Section**: Company information with feature highlights
5. **Newsletter**: Email subscription form
6. **Footer**: Links, contact info, and social media

## 🛠️ Installation & Setup

1. Clone or download the project files
2. Open `index.html` in your web browser
3. No additional setup required - it's a static website!

## 📁 Project Structure

```
dough-art/
├── index.html          # Main HTML file
├── styles.css          # CSS styles and responsive design
├── script.js           # JavaScript functionality
└── README.md           # Project documentation
```

## 🎨 Design Elements

- **Color Scheme**: 
  - Primary: #e74c3c (Red)
  - Secondary: #2c3e50 (Dark Blue)
  - Accent: #667eea (Purple gradient)
  - Background: #f8f9fa (Light Gray)

- **Typography**: Inter font family for modern, clean text
- **Animations**: Smooth transitions and hover effects
- **Layout**: CSS Grid and Flexbox for responsive design

## 🔧 Customization

To customize the website:

1. **Colors**: Update CSS custom properties in `styles.css`
2. **Content**: Modify text and images in `index.html`
3. **Functionality**: Add features in `script.js`
4. **Styling**: Adjust CSS classes and selectors

## 📸 Screenshots

The website features:
- Beautiful hero section with gradient background
- Product cards with hover animations
- Responsive navigation menu
- Newsletter subscription form
- Professional footer with social links

## 🌟 Features in Detail

### Navigation
- Fixed header with smooth scroll effects
- Mobile hamburger menu
- Search functionality
- Shopping cart with item counter

### Products
- Grid layout with responsive design
- Hover effects and animations
- Star ratings display
- Quick view buttons

### Animations
- Fade-in animations on scroll
- Smooth transitions
- Parallax effects
- Loading animations

### User Experience
- Smooth scrolling navigation
- Form validation
- Notification system
- Keyboard navigation support

## 🚀 Performance

- Optimized images with lazy loading
- Debounced scroll events
- Efficient CSS animations
- Minimal JavaScript footprint

## 📱 Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers

## 📄 License

This project is open source and available under the MIT License.

## 🤝 Contributing

Feel free to contribute to this project by:
1. Forking the repository
2. Creating a feature branch
3. Making your changes
4. Submitting a pull request

## 📞 Support

For support or questions, please contact:
- Email: info@doughart.com
- Phone: +1 (555) 123-4567

---

**Dough Art** - Creating beautiful dough art pieces that inspire and delight.

